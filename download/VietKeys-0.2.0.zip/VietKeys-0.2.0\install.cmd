@echo off
rem VietKeys: install from this folder to C:\Program Files\VietKeys (Start menu, Installed apps, start at sign-in).
rem Needs administrator rights: double-click it and Windows asks for them. Running it again updates VietKeys.
cd /d "%~dp0"
if not exist VietKeys.exe (
  echo VietKeys.exe is not in this folder. Extract the whole zip first, then run install.cmd again.
  pause
  exit /b 1
)

net session >nul 2>&1
if errorlevel 1 (
  echo Asking Windows for administrator rights...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)

start "" /wait VietKeys.exe --install
if errorlevel 1 (
  echo.
  echo Installation failed. If your antivirus blocked VietKeys.exe, allow it and run install.cmd again.
  pause
  exit /b 1
)

rem Start VietKeys without administrator rights (through Explorer), like a normal app
explorer.exe "%ProgramFiles%\VietKeys\VietKeys.exe"
echo.
echo VietKeys is installed and running. Tray icon: V = Vietnamese, E = English.
echo Ctrl+Shift switches Vietnamese typing on and off. Settings: right-click the tray icon.
echo You can delete this folder now.
pause
