﻿VietKeys - Windows 10 / 11 用ベトナム語入力 (Telex、VNI)
https://vietkeys.com  -  作者: Nguyen Ngoc Nam

他の言語のガイド: README-en.txt (English)、README-vi.txt (Tiếng Việt)、README-zh.txt (中文)


このフォルダーの中身
  VietKeys.exe     アプリ本体 (この 1 ファイルだけで動きます)
  install.cmd      VietKeys をこのパソコンにインストール
  uninstall.cmd    VietKeys を削除


インストール
  1. まず zip をすべて展開してください (zip を右クリック > すべて展開)。
     zip の中から直接実行しないでください。
  2. install.cmd をダブルクリックし、管理者権限の確認で「はい」を選びます。
     VietKeys は C:\Program Files\VietKeys にコピーされ、スタート メニューと
     「設定 > アプリ > インストールされているアプリ」に追加され、サインイン時に
     起動するよう設定されて、すぐに起動します。
  3. 時計の横のトレイに VietKeys のアイコンが表示されます: V = ベトナム語、E = 英語。
     (Windows 11 では ^ の中に隠れることがあります。外へドラッグすると常に表示されます。)
  インストール後、このフォルダーは削除してかまいません。

  「Windows によって PC が保護されました」と表示されたら:「詳細情報」>「実行」を選びます。
    VietKeys は新しく、まだコード署名証明書で署名されていないため、Windows が認識していません。
  ウイルス対策ソフトの警告: VietKeys はベトナム語を入力するためにキーボードを監視します。
    ウイルス対策ソフトはこの動作を警戒します。VietKeys.exe を許可してください。


インストールせずに使う
  VietKeys.exe をダブルクリックします。終了するまでこのフォルダーから動きます
  (トレイのアイコンを右クリック > 終了)。


入力方法
  ベトナム語のオン / オフ  Ctrl+Shift (押して離す)、またはトレイのアイコンをクリック。
                          設定で Alt+Z、Alt+Shift+Z、または好きなショートカットに変更できます。
  設定                    トレイのアイコンを右クリック > 設定...

  Telex   aa=â  ee=ê  oo=ô  aw=ă  ow=ơ  uw=ư  dd=đ
          s=sắc  f=huyền  r=hỏi  x=ngã  j=nặng  z=声調を消す
          Vieejt Nam -> Việt Nam      tieengs -> tiếng
  VNI     1=sắc  2=huyền  3=hỏi  4=ngã  5=nặng  6=â ê ô  7=ơ ư  8=ă  9=đ  0=声調を消す
          Vie65t Nam -> Việt Nam      tie61ng -> tiếng

  記号と声調は単語のどこで入力してもかまいません。英単語は入力どおりに残ります (Windows、class)。

  日本語 / 中国語 / 韓国語の IME: オン (あ、中、한) の間は、VietKeys はすべてのキーを
    IME に任せます。IME をオフ (A) にすると、VietKeys がまたベトナム語を入力します。
  ゲーム: 全画面のときは、VietKeys はキーを一切変更しません。ウィンドウで動くゲームは、
    プレイ中にトレイのアイコンを右クリック >「<ゲーム>.exe ではベトナム語入力をオフ」。
  Unikey など、ほかのベトナム語入力ツールと同時に使わないでください。


アンインストール
  設定 > アプリ > インストールされているアプリ > VietKeys > アンインストール、
  または uninstall.cmd をダブルクリック。


プライバシー
  VietKeys はインターネットに一切接続せず、何も収集・送信しません。
  入力した内容はあなたのパソコンの中だけにあります。
