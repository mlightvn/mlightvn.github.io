﻿VietKeys - 适用于 Windows 10 和 11 的越南语输入工具 (Telex、VNI)
https://vietkeys.com  -  作者：Nguyen Ngoc Nam

其他语言的说明：README-en.txt (English)、README-vi.txt (Tiếng Việt)、README-ja.txt (日本語)


文件夹内容
  VietKeys.exe     程序本体 (只有这一个文件，无需其他组件)
  install.cmd      在本机安装 VietKeys
  uninstall.cmd    卸载 VietKeys


安装
  1. 请先解压整个 zip (右键单击 zip > 全部解压缩)。
     不要直接在 zip 里运行文件。
  2. 双击 install.cmd，Windows 请求管理员权限时选择“是”。
     VietKeys 会被复制到 C:\Program Files\VietKeys，添加到“开始”菜单和
     “设置 > 应用 > 已安装的应用”，设置为登录时自动启动，并立即运行。
  3. 时钟旁的托盘中会出现 VietKeys 图标：V = 越南语，E = 英语。
     (Windows 11 可能把它藏在 ^ 箭头里：把它拖出来即可一直显示。)
  安装后可以删除这个文件夹。

  出现“Windows 已保护你的电脑”：点击“更多信息”，再点击“仍要运行”。
    VietKeys 是新程序，尚未使用代码签名证书签名，所以 Windows 还不认识它。
  杀毒软件警告：VietKeys 需要监视键盘才能输入越南语，这正是杀毒软件会关注的行为。
    请允许 VietKeys.exe。


免安装使用
  双击 VietKeys.exe。它会在这个文件夹中运行，直到你退出
  (右键单击托盘图标 > Exit)。


输入方法
  开启 / 关闭越南语   Ctrl+Shift (按下后松开)，或单击托盘图标。
                      可在设置中改为 Alt+Z、Alt+Shift+Z 或自定义快捷键。
  设置                右键单击托盘图标 > Settings...
                      (VietKeys 的界面为英语、越南语和日语)

  Telex   aa=â  ee=ê  oo=ô  aw=ă  ow=ơ  uw=ư  dd=đ
          s=sắc  f=huyền  r=hỏi  x=ngã  j=nặng  z=去掉声调
          Vieejt Nam -> Việt Nam      tieengs -> tiếng
  VNI     1=sắc  2=huyền  3=hỏi  4=ngã  5=nặng  6=â ê ô  7=ơ ư  8=ă  9=đ  0=去掉声调
          Vie65t Nam -> Việt Nam      tie61ng -> tiếng

  符号和声调可以在单词的任意位置输入。英文单词保持原样 (Windows、class)。

  日语 / 中文 / 韩语输入法：开启时 (あ、中、한)，VietKeys 会把所有按键交给该输入法。
    关闭它 (A) 后，VietKeys 又会输入越南语。
  游戏：全屏时 VietKeys 不改动任何按键。对于窗口模式的游戏，游戏时右键单击托盘图标 >
    “Vietnamese typing off in <游戏>.exe”。
  不要同时运行 Unikey 或其他越南语输入工具。


卸载
  设置 > 应用 > 已安装的应用 > VietKeys > 卸载，或双击 uninstall.cmd。


隐私
  VietKeys 从不连接互联网，不收集也不发送任何内容：
  你输入的内容只保留在你的电脑上。
