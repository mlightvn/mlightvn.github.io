@echo off
rem VietKeys: remove VietKeys (Program Files, Start menu, Installed apps, start at sign-in, settings).
rem Same as Settings > Apps > Installed apps > VietKeys > Uninstall. Asks for administrator rights.
cd /d "%~dp0"
net session >nul 2>&1
if errorlevel 1 (
  echo Asking Windows for administrator rights...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
  exit /b
)
if exist "%ProgramFiles%\VietKeys\VietKeys.exe" (
  start "" /wait "%ProgramFiles%\VietKeys\VietKeys.exe" --uninstall
) else (
  start "" /wait VietKeys.exe --uninstall
)
pause
