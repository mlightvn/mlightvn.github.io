﻿VietKeys - Vietnamese typing for Windows 10 and 11 (Telex, VNI)
https://vietkeys.com  -  by Nguyen Ngoc Nam

Guides in other languages: README-vi.txt (Tiếng Việt), README-ja.txt (日本語), README-zh.txt (中文)


IN THIS FOLDER
  VietKeys.exe     the app (one file, nothing else needed)
  install.cmd      installs VietKeys on this computer
  uninstall.cmd    removes VietKeys


INSTALL
  1. Extract the whole zip first (right-click the zip > Extract All).
     Do not run the files from inside the zip.
  2. Double-click install.cmd and answer Yes when Windows asks for administrator rights.
     VietKeys is copied to C:\Program Files\VietKeys, added to the Start menu and to
     Settings > Apps > Installed apps, set to start when you sign in, and started.
  3. The VietKeys icon appears in the tray next to the clock: V = Vietnamese, E = English.
     (Windows 11 may hide it under the ^ arrow: drag it out to keep it visible.)
  You can delete this folder afterwards.

  "Windows protected your PC": click "More info", then "Run anyway".
    VietKeys is new and not signed with a code-signing certificate yet, so Windows does not know it.
  Antivirus warning: VietKeys watches the keyboard to type Vietnamese, which antivirus
    programs look for. Allow VietKeys.exe.


USE WITHOUT INSTALLING
  Double-click VietKeys.exe. It runs from this folder until you exit it
  (right-click the tray icon > Exit).


TYPING
  Vietnamese on / off   Ctrl+Shift (press and release), or click the tray icon.
                        Settings can use Alt+Z, Alt+Shift+Z or your own shortcut instead.
  Settings              right-click the tray icon > Settings...

  Telex   aa=â  ee=ê  oo=ô  aw=ă  ow=ơ  uw=ư  dd=đ
          s=sắc  f=huyền  r=hỏi  x=ngã  j=nặng  z=no tone
          Vieejt Nam -> Việt Nam      tieengs -> tiếng
  VNI     1=sắc  2=huyền  3=hỏi  4=ngã  5=nặng  6=â ê ô  7=ơ ư  8=ă  9=đ  0=no tone
          Vie65t Nam -> Việt Nam      tie61ng -> tiếng

  Marks and tones can come anywhere in the word. English words stay as typed (Windows, class).

  Japanese / Chinese / Korean input method: while it is on (あ, 中, 한), VietKeys leaves
    every key to it. Switch it off (A) and VietKeys types Vietnamese again.
  Games: in full screen VietKeys leaves every key alone. For a game in a window, right-click
    the tray icon while playing > "Vietnamese typing off in <game>.exe".
  Do not run Unikey or another Vietnamese typing tool at the same time.


UNINSTALL
  Settings > Apps > Installed apps > VietKeys > Uninstall, or double-click uninstall.cmd.


PRIVACY
  VietKeys never connects to the internet. It does not collect or send anything:
  what you type stays on your computer.
