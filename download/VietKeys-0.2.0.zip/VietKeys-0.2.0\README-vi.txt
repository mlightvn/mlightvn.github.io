﻿VietKeys - Bộ gõ tiếng Việt cho Windows 10 và 11 (Telex, VNI)
https://vietkeys.com  -  Tác giả: Nguyen Ngoc Nam

Hướng dẫn bằng ngôn ngữ khác: README-en.txt (English), README-ja.txt (日本語), README-zh.txt (中文)


TRONG THƯ MỤC NÀY
  VietKeys.exe     chương trình (chỉ một file, không cần cài thêm gì)
  install.cmd      cài VietKeys vào máy
  uninstall.cmd    gỡ VietKeys


CÀI ĐẶT
  1. Giải nén toàn bộ file zip trước (chuột phải vào file zip > Extract All).
     Đừng chạy file ngay bên trong zip.
  2. Nhấp đúp install.cmd, chọn Yes khi Windows hỏi quyền quản trị.
     VietKeys được chép vào C:\Program Files\VietKeys, thêm vào menu Start và
     Settings > Apps > Installed apps, tự chạy khi đăng nhập Windows, và chạy ngay.
  3. Icon VietKeys hiện ở khay hệ thống cạnh đồng hồ: V = tiếng Việt, E = tiếng Anh.
     (Windows 11 có thể giấu icon trong mũi tên ^: kéo ra ngoài để luôn thấy.)
  Cài xong có thể xóa thư mục này.

  "Windows protected your PC": bấm "More info", rồi "Run anyway".
    VietKeys còn mới và chưa được ký bằng chứng thư số (code signing) nên Windows chưa nhận ra.
  Phần mềm diệt virus cảnh báo: VietKeys theo dõi bàn phím để gõ tiếng Việt, đúng điều
    mà phần mềm diệt virus hay để ý. Hãy cho phép VietKeys.exe.


DÙNG KHÔNG CẦN CÀI
  Nhấp đúp VietKeys.exe. Chương trình chạy từ thư mục này cho tới khi bạn thoát
  (chuột phải icon ở khay > Thoát).


CÁCH GÕ
  Bật / tắt tiếng Việt  Ctrl+Shift (nhấn rồi thả), hoặc bấm vào icon ở khay.
                        Trong Cài đặt có thể đổi sang Alt+Z, Alt+Shift+Z hoặc phím tắt tự chọn.
  Cài đặt               chuột phải icon ở khay > Cài đặt...

  Telex   aa=â  ee=ê  oo=ô  aw=ă  ow=ơ  uw=ư  dd=đ
          s=sắc  f=huyền  r=hỏi  x=ngã  j=nặng  z=xóa dấu
          Vieejt Nam -> Việt Nam      tieengs -> tiếng
  VNI     1=sắc  2=huyền  3=hỏi  4=ngã  5=nặng  6=â ê ô  7=ơ ư  8=ă  9=đ  0=xóa dấu
          Vie65t Nam -> Việt Nam      tie61ng -> tiếng

  Dấu có thể gõ ở bất kỳ đâu trong từ. Từ tiếng Anh được giữ nguyên (Windows, class).

  Bộ gõ tiếng Nhật / Trung / Hàn: khi đang bật (あ, 中, 한), VietKeys để nguyên mọi phím
    cho bộ gõ đó. Tắt nó đi (A) thì VietKeys lại gõ tiếng Việt.
  Chơi game: khi toàn màn hình, VietKeys để nguyên mọi phím. Game chạy trong cửa sổ thì
    chuột phải icon ở khay khi đang chơi > "Tắt gõ tiếng Việt trong <game>.exe".
  Đừng chạy Unikey hay bộ gõ tiếng Việt khác cùng lúc.


GỠ CÀI ĐẶT
  Settings > Apps > Installed apps > VietKeys > Uninstall, hoặc nhấp đúp uninstall.cmd.


QUYỀN RIÊNG TƯ
  VietKeys không bao giờ kết nối Internet, không thu thập hay gửi đi bất cứ thứ gì:
  những gì bạn gõ chỉ ở trên máy của bạn.
